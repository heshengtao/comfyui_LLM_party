# Security Policy
- The security file is not enabled for the time being. The following are just examples. It will be enabled in the future to report version security
- 暂时未启用该安全文件，以下仅为示例，未来会启用以报告版本的安全性
