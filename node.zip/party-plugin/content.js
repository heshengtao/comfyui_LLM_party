// This file can be empty for now, as we are not injecting any content scripts.
